import requests

BASE = "http://127.0.0.1:5000/"


# Run this to check if the user guessed a valid word
# @PARAMS NEEDED: word
# @RETURNS valid or not valid
# @SYNTAX: {base address}/check_word/{word}
response = requests.get(BASE + "check_word/skate") # should be valid
print(response.json())
response = requests.get(BASE + "check_word/ppppp") # should be invalid
print(response.json())
response = requests.get(BASE + "check_word/volpe") # should be invalid
print(response.json())


# Run this to get a solution word from the database.
# This is mainly for testing and most likely won't be used on its own, but its here just in case
# @PARAMS NEEDED: none
# @RETURNS: solution word
# @SYNTAX: {base address}/solution_word
response = requests.get(BASE + "solution_word")
print(response.json())


# Run this when there is a new user. This will return a new user_id.
# Save the user_id, its needed to start a new session
# @PARAMS NEEDED: none
# @RETURNS: user_id
# @SYNTAX: {base address}/user_id
response = requests.get(BASE + "user_id")
print(response.json())
user_id = response.json()['user_id']


# Run this when the user wants to start a new Wordle session.
# @PARAMS NEEDED: user_id
# @RETURNS: session_id, solution_word for that session
# @SYNTAX: {base address}/new_session/{user_id}
response = requests.get(BASE + "new_session/" + user_id)
print(response.json())


# Run this when a game finishes. This will return the updated scorecard for that user.
# @PARAMS NEEDED: user_id, result of game (win/lose), and number of guesses (if win) 
# @RETURNS: user scorecard (user_id/streaks/wins/losses)
# @SYNTAX: {base address}/results/{user_id}/{win_or_lose}/{num_guesses}
response = requests.get(BASE + "results/" + user_id + "/" + "W" + '/' + '2')
print(response.json())


# Testing several more times with different values to ensure the scorecard updates correctly
response = requests.get(BASE + "results/" + user_id + "/" + "W" + '/' + '4')
print(response.json())
response = requests.get(BASE + "results/" + user_id + "/" + "W" + '/' + '6')
print(response.json())
response = requests.get(BASE + "results/" + user_id + "/" + "L" + '/' + '0')
print(response.json())
response = requests.get(BASE + "results/" + user_id + "/" + "L" + '/' + '0')
print(response.json())
response = requests.get(BASE + "results/" + user_id + "/" + "L" + '/' + '0')
print(response.json())