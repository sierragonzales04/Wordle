/*
Team Blue: Emma Kennedy, Sierra Gonzales, Matthew Miller, Kevin Xia
CS362 Spring 2024
Professor Sheehy
*/

class Wordle {
    constructor() {
        // Initialize values
        this.baseAddress = 'http://127.0.0.1:5000/';
        this.userid = '';
        this.sessionid = [];
        this.guesses = [];
        this.currentGuess = [];
        this.exactLetters = [];
        this.validLetters = [];
        this.invalidLetters = [];
        this.gameRunning = true;
        this.modalOn = false;
        this.userStartsNewSession();

        // Left Div
        this.div = document.getElementById('main');
        this.display = 0;
        var gameJustEnded;
        document.getElementById("statistics").addEventListener("click", async () => {await this.toggleModal()})

        // Restart Button
        document.getElementById("restartButton").addEventListener("click", async () => await this.userStartsNewSession());
        document.onkeydown = (e) => this.keyPressed(e);

        // Pop up after each game
        this.myModal = document.getElementById("exampleModal");
        this.myModal.style.display = "none";

        // X button to close the pop up
        document.getElementById("closeModal").addEventListener("click", async () => await this.closeModal());

        // Add on screen keyboard
        this.activateOnScreenKeyboard()
    }

    activateOnScreenKeyboard(){
        document.getElementById("KeyA").addEventListener("click", () => this.callKeyPressOnScreen('KeyA'));
        document.getElementById("KeyB").addEventListener("click", () => this.callKeyPressOnScreen('KeyB'));
        document.getElementById("KeyC").addEventListener("click", () => this.callKeyPressOnScreen('KeyC'));
        document.getElementById("KeyD").addEventListener("click", () => this.callKeyPressOnScreen('KeyD'));
        document.getElementById("KeyE").addEventListener("click", () => this.callKeyPressOnScreen('KeyE'));
        document.getElementById("KeyF").addEventListener("click", () => this.callKeyPressOnScreen('KeyF'));
        document.getElementById("KeyG").addEventListener("click", () => this.callKeyPressOnScreen('KeyG'));
        document.getElementById("KeyH").addEventListener("click", () => this.callKeyPressOnScreen('KeyH'));
        document.getElementById("KeyI").addEventListener("click", () => this.callKeyPressOnScreen('KeyI'));
        document.getElementById("KeyJ").addEventListener("click", () => this.callKeyPressOnScreen('KeyJ'));
        document.getElementById("KeyK").addEventListener("click", () => this.callKeyPressOnScreen('KeyK'));
        document.getElementById("KeyL").addEventListener("click", () => this.callKeyPressOnScreen('KeyL'));
        document.getElementById("KeyM").addEventListener("click", () => this.callKeyPressOnScreen('KeyM'));
        document.getElementById("KeyN").addEventListener("click", () => this.callKeyPressOnScreen('KeyN'));
        document.getElementById("KeyO").addEventListener("click", () => this.callKeyPressOnScreen('KeyO'));
        document.getElementById("KeyP").addEventListener("click", () => this.callKeyPressOnScreen('KeyP'));
        document.getElementById("KeyQ").addEventListener("click", () => this.callKeyPressOnScreen('KeyQ'));
        document.getElementById("KeyR").addEventListener("click", () => this.callKeyPressOnScreen('KeyR'));
        document.getElementById("KeyS").addEventListener("click", () => this.callKeyPressOnScreen('KeyS'));
        document.getElementById("KeyT").addEventListener("click", () => this.callKeyPressOnScreen('KeyT'));
        document.getElementById("KeyU").addEventListener("click", () => this.callKeyPressOnScreen('KeyU'));
        document.getElementById("KeyV").addEventListener("click", () => this.callKeyPressOnScreen('KeyV'));
        document.getElementById("KeyW").addEventListener("click", () => this.callKeyPressOnScreen('KeyW'));
        document.getElementById("KeyX").addEventListener("click", () => this.callKeyPressOnScreen('KeyX'));
        document.getElementById("KeyY").addEventListener("click", () => this.callKeyPressOnScreen('KeyY'));
        document.getElementById("KeyZ").addEventListener("click", () => this.callKeyPressOnScreen('KeyZ'));
        document.getElementById("KeyEnter").addEventListener("click", () => this.callKeyPressOnScreen('Enter')); // Enter button
        document.getElementById("KeyBackspace").addEventListener("click", () => this.callKeyPressOnScreen('Backspace')); // Backspace button
    }

    async userStartsNewSession(){
        if (this.userid === ""){
            await this.getNewUser()
        }
        await this.startNewSession()
        this.guesses = [];
        this.currentGuess = [];
        this.exactLetters = [];
        this.validLetters = [];
        this.invalidLetters = [];
        document.getElementById("win").textContent = "On going game";
        this.clearGrid();
        this.gameRunning = true;

        var myModal = document.getElementById("exampleModal");
        myModal.style.display = "none";
    }

    // Call to the API
    // Gets a new user id from the backend DB
    async getNewUser(){
        await fetch(`${this.baseAddress}user_id`)
            .then(res => {
                return res.json()
            })
            .then(data => {
                this.userid = data['user_id']
                console.log('New user: ' + this.userid +' has joined')
            })
            .catch(data => {
                console.log("Something went wrong")
            })
    }

    // Call to the API
    // Starts a new session
    async startNewSession(){
        this.myModal.style.display = "none";
        statistics.innerHTML = 'Show Statistics';
        this.hideResetButton();
        let solution_word
        await fetch(`${this.baseAddress}new_session/${this.userid}`)
            .then(res => {
                return res.json()
            })
            .then(data => {
                solution_word = data['new_session_started']['solution_word']
                this.sessionid = data['new_session_started']['session_id']
                console.log('Obtained new word ' + solution_word +' from SQL Server.');
                console.log('Started new session id ' + this.sessionid)
            })
            .catch(data => {
                console.log("Something went wrong")
            })
    }

    // Gets a solution word from the backend DB
    async getSolutionWord(){
        let solution_word;
        await fetch(`${this.baseAddress}get_solution_word/${this.sessionid}`)
            .then(res => {
                return res.json();
            })
            .then(data => {
                solution_word = data['solution_word_for_this_session'];
            })
            .catch(data => {
                console.log("Something went wrong")
            })
        return solution_word
    }

    // Clears game grid upon a new game or restart game
    clearGrid() {
        for (let i = 1; i <= 6; i++) {
            for (let j = 1; j <= 5; j++) {
                let cell = document.getElementById("R" + i + "C" + j);
                cell.textContent = "";
                cell.style.backgroundColor = "#121212";
                cell.style.borderColor = "#3A3A3C";
                cell.style.animation = 'none'; // Reset animation
            }
        }
        let letters = ['A','B','C','D','E','F','G','H','I','J','K','L','M',
                        'N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
        for (let i = 0; i < 26; i++){
            let keyboardKey = document.getElementById("Key" + letters[i]);
            keyboardKey.style.backgroundColor = "#121212";
            keyboardKey.style.borderColor = "#3A3A3C";
        }
    }
    
    // Called when user wins, updates backend DB
    async UserWon(guesses) {
        if (guesses === 0){
            document.getElementById("win").textContent = "Phew!";
        }
        else{
            document.getElementById("win").textContent = "YOU WIN!";
        }
        await fetch(`${this.baseAddress}/send_results/${this.userid}/W/${6-guesses}`)
            .catch(data => {
                console.log("Something went wrong")
            })
        this.gameRunning = false;
        setTimeout(async()=>{await this.getUserReport("YOU WIN!");}, 3000);
        this.showResetButton();
    }

    // Called when user loses, updates backend DB
    async UserLost() {
        document.getElementById("win").textContent = "YOU LOSE!";
        await fetch(`${this.baseAddress}/send_results/${this.userid}/L/0`)
            .catch(data => {
                console.log("Something went wrong")
            })
        this.gameRunning = false;
        setTimeout(async()=>{await this.getUserReport("YOU LOSE!");}, 3000);
        this.showResetButton();
    }

    // Called upon user request, gets stats from backend DB
    async getUserReport(gameMessage){
        await fetch(`${this.baseAddress}/get_player_report/${this.userid}`)
            .then(res => {
                return res.json()
            })
            .then(data => {
                var wins = data['player_record']['wins'];
                var losses = data['player_record']['losses'];
                var streak = data['player_record']['streak'];
                var _1G = data['player_record']['1G'];
                var _2G = data['player_record']['2G'];
                var _3G = data['player_record']['3G'];
                var _4G = data['player_record']['4G'];
                var _5G = data['player_record']['5G'];
                var _6G = data['player_record']['6G'];
                var winPercent = Math.round(100 * wins / (wins + losses));

                document.getElementById('message').innerHTML = gameMessage;
                document.getElementById('_wins').innerHTML = wins;
                document.getElementById('_losses').innerHTML = losses;
                document.getElementById('__1G').innerHTML = _1G;
                document.getElementById('__2G').innerHTML = _2G;
                document.getElementById('__3G').innerHTML = _3G;
                document.getElementById('__4G').innerHTML = _4G;
                document.getElementById('__5G').innerHTML = _5G;
                document.getElementById('__6G').innerHTML = _6G;
                document.getElementById('winPercent').innerHTML = winPercent;

                if (streak < 0){
                    streak = streak * -1;
                    document.getElementById('_streak').innerHTML = "L" + streak;
                }
                else{
                    document.getElementById('_streak').innerHTML = "W" + streak;
                }
            })
            .catch(data => {
                console.log("Something went wrong")
            })
        this.myModal.style.display = "block";
        statistics.innerHTML = 'Hide Statistics';
    }

    guessesLeft() {
        return 6 - this.guesses.length;
    }

    // Call to the API
    // Checks if a user's guess is a valid guess in the DB
    async validOrNot(word) {
        let valid;
        if (word.length !== 5) {
            return false;
        }
        await fetch('http://127.0.0.1:5000/check_word/' + word)
        .then(res => {
            return res.json()
        })
        .then(data => {
            console.log(word + ' is ' + data['check_word']);
            if (data['check_word'] === 'valid'){
                valid = true;
            }
            else if (data['check_word'] === 'not_valid'){
                valid = false;
            }
            else{
                valid = false;
            }
        })
        .catch(data => {
            console.log("Something went wrong")
        })
        if (valid === true){
            return true
        }
        else{
            return false
        }
    }

    // Keeps track of correctly guessed letters in the correct spots
    addExact(letter) {
        if (this.exactLetters.indexOf(letter) === -1) {
            this.exactLetters.push(letter);
            document.getElementById("Key" + letter).style.backgroundColor = "#538D4E";
            document.getElementById("Key" + letter).style.borderColor = "#538D4E";
        }
    }

    // Keeps track of correctly guessed letters in the incorrect spots
    addValid(letter) {
        if (this.validLetters.indexOf(letter) === -1) {
            this.validLetters.push(letter);
        }
    }

    // Keeps track of incorrectly guessed letters
    addInvalid(letter) {
        if (this.invalidLetters.indexOf(letter) === -1) {
            this.invalidLetters.push(letter);
            document.getElementById("Key" + letter).style.backgroundColor = "#3A3A3C";
            document.getElementById("Key" + letter).style.borderColor = "#3A3A3C";
        }
    }

    // Call to the API
    // Runs when the user submits a guess
    // Checks which letters in the guess are correct / incorrect
    async guess(word) {
        var valid = await this.validOrNot(word)
        if (!valid){
            document.getElementById("win").textContent = `${word} is invalid`;
            return false;
        }
        document.getElementById("win").textContent = `${word} is valid`;
        var solution_word = await this.getSolutionWord();
        this.guesses.push(word);
        for (let i = 0; i < word.length; i++) {
            var cell = document.getElementById("R" + this.guesses.length + "C" + (i + 1))
            if (word[i] === solution_word[i]) {
                this.addExact(word[i]);
                cell.style.animation = "flipExact 0.5s ease-in-out " + (i * 0.5) + "s forwards";
            } else if (solution_word.includes(word[i])) {
                this.addValid(word[i]);
                cell.style.animation = "flipValid 0.5s ease-in-out " + (i * 0.5) + "s forwards";
            } else {
                this.addInvalid(word[i]);
                cell.style.animation = "flipInvalid 0.5s ease-in-out " + (i * 0.5) + "s forwards";
            }
            document.getElementById("R" + this.guesses.length + "C" + (i + 1)).textContent = word[i];
        }
        if (word === solution_word) {
            this.UserWon(this.guessesLeft());
        } else if (this.guessesLeft() === 0) {
            this.UserLost();
        }
        this.currentGuess = [];
        return true;
    }

    colorCell(cell, color) {
        cell.style.backgroundColor = color;
        cell.style.borderColor = color;
    }

    // Logs the user's keystrokes
    keyPressed = (e) => {
        if (this.gameRunning == true) {
            if (e.code == 'Enter' && this.currentGuess.length == 5) {
                this.guess(this.currentGuess.join(""));
            } else {
                if (e.code.length == 4 && e.code.slice(0, 3) == "Key") {
                    let b = ("" + `${e.code}`).slice(3, 4);
                    if (this.currentGuess.length < 5) {
                        this.currentGuess.push(b);
                        var cell = document.getElementById("R" + (this.guesses.length + 1) + "C" + (this.currentGuess.length));
                        cell.textContent = b;
                        cell.style.borderColor = "#565758";
                        cell.style.animation = 'none';
                        cell.offsetHeight;
                        cell.style.animation = null;
                        cell.style.animation = "pop 0.1s ease alternate";
                    }
                } else if (e.code == "Backspace") {
                    this.currentGuess.pop();
                    document.getElementById("R" + (this.guesses.length + 1) + "C" + (this.currentGuess.length + 1)).textContent = "";
                    document.getElementById("R" + (this.guesses.length + 1) + "C" + (this.currentGuess.length + 1)).style.borderColor = "#3A3A3C";
                }
            }
        }
    }

    // Logs the user's on screen keyboard keystrokes
    keyPressedOnScreen = (e) => {
        if (this.gameRunning == true) {
            if (e == 'Enter' && this.currentGuess.length == 5) {
                this.guess(this.currentGuess.join(""));
            } else {
                if (e.length == 4 && e.slice(0, 3) == "Key") {
                    let b = ("" + `${e}`).slice(3, 4);
                    if (this.currentGuess.length < 5) {
                        this.currentGuess.push(b);
                        var cell = document.getElementById("R" + (this.guesses.length + 1) + "C" + (this.currentGuess.length));
                        cell.textContent = b;
                        cell.style.borderColor = "#565758";
                        cell.style.animation = 'none';
                        cell.offsetHeight;
                        cell.style.animation = null;
                        cell.style.animation = "pop 0.1s ease alternate";
                    }
                } else if (e == "Backspace") {
                    this.currentGuess.pop();
                    document.getElementById("R" + (this.guesses.length + 1) + "C" + (this.currentGuess.length + 1)).textContent = "";
                    document.getElementById("R" + (this.guesses.length + 1) + "C" + (this.currentGuess.length + 1)).style.borderColor = "#3A3A3C";
                }
            }
        }
    }

    // Toggles the user stats pop up
    async toggleModal(){
        if(this.myModal.style.display === 'block'){
            await this.closeModal();

        }
        else if(this.myModal.style.display === 'none'){
            await this.showModal();
            statistics.innerHTML = 'Hide Statistics';
        }
    }

    // Toggles the user stats pop up
    async showModal(){
        await this.getUserReport("");
        this.myModal.style.display = "block";
        statistics.innerHTML = 'Hide Statistics';
    }

    // Toggles the user stats pop up
    async closeModal(){
        this.myModal.style.display = "none";
        statistics.innerHTML = 'Show Statistics';
    }

    callKeyPressOnScreen(key) {
        this.keyPressedOnScreen(key);
    }

    showResetButton() {
        document.getElementById("restartButton").style.display = 'block';
    }
    hideResetButton() {
        document.getElementById("restartButton").style.display = 'none';
    }

}

// Allows user to add a valid guess word to the DB during a game
async function createValidWord(word){
    let success = false;
    baseAddress = 'http://127.0.0.1:5000/';
    await fetch(`${baseAddress}create_new_valid_word/${word}`)
        .then(res => {
            return res.json()
        })
        .then(data => {
            if (data["new_valid_word"] != "unable to create new valid word"){
                success = true;
            }
        })
        .catch(data => {
            console.log("Something went wrong")
        })
    if (success === true){
        console.log("Added " + word + " to the database");
    }
    else{
        console.log("Unable to add " + word + " to the database");
    }
}

function main() {
    var test = new Wordle();
    document.write(test.exactLetters);
    document.onkeydown = test.keyPressed;
}

main();

